#!/usr/bin/env python3

import asyncio
import json
import os
from pathlib import Path
import sys
import datetime
import traceback
from openai import OpenAI

# Import the new relationship modules
from relationship_content_generator import (
    generate_relationship_title_content,
    generate_relationship_story_content,
    generate_short_relationship_content,  # New short content function
    generate_relationship_conclusion_content,
    generate_instagram_caption,
    load_story_ideas_from_file,
    get_random_story_scenario,
    generate_varied_relationship_content,
    RELATIONSHIP_STORY_TEMPLATES
)
from relationship_template_generator import (
    generate_relationship_title_template,
    generate_relationship_story_template,
    generate_short_relationship_content_template,  # New short content template
    generate_relationship_conclusion_template,
    generate_relationship_end_template
)
from image_generator import generate_images_from_templates
from telegram_sender import send_telegram_photos
from config import setup_environment
import os
from openai import OpenAI
from ig_optimization import InstagramOptimizer, create_optimized_caption  # 新增優化系統

async def generate_relationship_content():
    """主要功能：生成關係故事內容，包含完整優化"""
    try:
        # Setup environment and get clients
        print("\n=== 🚀 設定環境 ===")
        clients = setup_environment()
        
        # 初始化 Instagram 優化器
        ig_optimizer = InstagramOptimizer()
        print("✅ Instagram 優化系統已啟動")
        
        # Generate varied content using random scenarios
        print("\n=== 🤖 生成 AI 內容 ===")
        content_data = await generate_varied_relationship_content(clients['openai_client'])
        
        # Extract generated content
        scenario = content_data['scenario']
        title_content = content_data['title_content'] 
        story_content = content_data['story_content']
        conclusion_content = content_data['conclusion_content']
        ig_caption = content_data['ig_caption']
        
        # 📊 內容分析和優化建議
        print("\n=== 📊 內容優化分析 ===")
        story_text = " ".join([point['description'][:100] for point in story_content['story_points']])
        performance_analysis = ig_optimizer.analyze_content_performance(story_text)
        optimal_time = ig_optimizer.get_optimal_posting_time()
        hashtag_strategy = ig_optimizer.generate_hashtag_strategy(scenario['theme'])
        
        print(f"📈 內容評分: {performance_analysis['score']}/100 ({performance_analysis['rating']})")
        print(f"⏰ 最佳發布時間: {optimal_time}")
        print(f"🏷️ 標籤策略: {len(sum(hashtag_strategy.values(), []))} 個精準標籤")
        print(f"💡 優化建議: {', '.join(performance_analysis['feedback'])}")
        
        print(f"\n=== 📝 生成內容摘要 ===")
        print(f"🎭 主題：{scenario['theme']}")
        print("📰 標題:", json.dumps(title_content, indent=2, ensure_ascii=False))
        print(f"📖 故事要點: {len(story_content['story_points'])} 個")
        print(f"💭 結論: {conclusion_content['conclusion'][:50]}...")
        print(f"📱 IG Caption 預覽: {ig_caption[:100]}...")
        
        # Save the Instagram caption to file with optimization info
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        caption_filename = 'generated_ig_caption.txt'
        with open(caption_filename, 'w', encoding='utf-8') as f:
            f.write(f"🎭 主題：{scenario['theme']}\n")
            f.write(f"⏰ 生成時間：{timestamp}\n")
            f.write(f"📈 內容評分：{performance_analysis['score']}/100\n")
            f.write(f"🕐 最佳發布時間：{optimal_time}\n")
            f.write(f"🏷️ 標籤數量：{len(sum(hashtag_strategy.values(), []))} 個\n\n")
            f.write("=== 優化建議 ===\n")
            for tip in performance_analysis['feedback']:
                f.write(f"• {tip}\n")
            f.write(f"\n=== Instagram Caption ===\n")
            f.write(ig_caption)
            f.write(f"\n\n=== 標籤策略明細 ===\n")
            for category, tags in hashtag_strategy.items():
                f.write(f"{category}: {' '.join(tags)}\n")
        print(f"📄 Instagram標題已保存到：{caption_filename}")
        
        # Generate HTML templates
        print("\n=== 🎨 生成 HTML 模板 ===")
        
        # Get perspective from scenario
        perspective = scenario.get('perspective', 'female')
        print(f"👤 使用視角：{perspective} ({'男性' if perspective == 'male' else '女性'})")
        
        templates = {
            'title': generate_relationship_title_template(
                title_content, 
                title_content['keywords'],
                perspective=perspective
            ),
            'story1': generate_relationship_story_template(
                story_content['story_points'][0], 
                story_content['keywords'],
                page_number=1,
                perspective=perspective
            ),
            'story2': generate_relationship_story_template(
                story_content['story_points'][1], 
                story_content['keywords'],
                page_number=2,
                perspective=perspective
            ),
            'story3': generate_relationship_story_template(
                story_content['story_points'][2], 
                story_content['keywords'],
                page_number=3,
                perspective=perspective
            ),
            'conclusion': generate_relationship_conclusion_template(
                conclusion_content, 
                story_content['keywords'],
                perspective=perspective
            ),
            'end': generate_relationship_end_template(perspective=perspective)
        }
        
        # Generate images from templates
        print("\n=== 🖼️ 生成圖片 ===")
        png_paths = await generate_images_from_templates(templates, f"relationship_{timestamp}")
        
        # Send to Telegram if images were generated successfully
        if png_paths:
            print("\n=== 📱 發送到 Telegram ===")
            
            # 創建增強版 Telegram 標題，包含優化信息
            telegram_caption = f"""🎭 {scenario['theme']} 故事
⏰ 生成時間：{timestamp}
📈 內容評分：{performance_analysis['score']}/100
🕐 建議發布：{optimal_time}
🏷️ 標籤策略：{len(sum(hashtag_strategy.values(), []))} 個精準標籤

{ig_caption}"""
            
            success = await send_telegram_photos(
                clients['telegram_bot'], 
                clients['telegram_chat_id'], 
                png_paths, 
                telegram_caption
            )
            if not success:
                print("❌ Telegram 發送失敗，但內容已生成完成")
        else:
            print("❌ 無圖片生成，跳過 Telegram 上傳")
        
        # 📅 生成發布時間表
        schedule = ig_optimizer.get_posting_schedule(7)
        print(f"\n=== 📅 一週發布時間表 ===")
        for day_plan in schedule[:3]:  # 顯示前3天
            print(f"📅 {day_plan['date']} ({day_plan['day']}) - {day_plan['time']} - {day_plan['reason']}")
        
        return {
            'scenario': scenario,
            'title_content': title_content,
            'story_content': story_content,
            'conclusion_content': conclusion_content,
            'ig_caption': ig_caption,
            'templates': templates,
            'png_paths': png_paths,
            'timestamp': timestamp,
            'optimization': {
                'performance': performance_analysis,
                'optimal_time': optimal_time,
                'hashtag_strategy': hashtag_strategy,
                'schedule': schedule
            }
        }
        
    except Exception as e:
        print(f"❌ 發生錯誤: {str(e)}")
        raise

async def main_short_content():
    """短版內容生成：包含完整 IG 優化"""
    try:
        # Initialize OpenAI client and IG optimizer
        print("\n=== 🚀 初始化系統 ===")
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if not openai_api_key:
            # Load from .env file
            from dotenv import load_dotenv
            load_dotenv()
            openai_api_key = os.getenv("OPENAI_API_KEY")
        
        openai_client = OpenAI(api_key=openai_api_key)
        ig_optimizer = InstagramOptimizer()
        print("✅ Instagram 優化系統已啟動")
        
        # Load story ideas from file
        story_ideas = load_story_ideas_from_file()
        
        if not story_ideas:
            print("📝 使用預設故事...")
            story_content = "我同男朋友一齊咗好耐，但最近覺得佢對我越來越冷淡..."
        else:
            story_content = story_ideas[0]['content']
            print(f"📖 使用故事: {story_content[:100]}...")
        
        # Generate scenario
        scenario = get_random_story_scenario()
        perspective = scenario.get('perspective', 'female')
        
        print(f"👤 生成{perspective}視角內容...")
        
        # 📊 預先分析內容
        performance_analysis = ig_optimizer.analyze_content_performance(story_content)
        optimal_time = ig_optimizer.get_optimal_posting_time()
        
        print(f"📈 內容評分: {performance_analysis['score']}/100")
        print(f"⏰ 最佳發布時間: {optimal_time}")
        
        # Generate title content
        print("🎯 生成標題內容...")
        title_content = await generate_relationship_title_content(openai_client, story_content, scenario)
        
        # Generate SHORT content (instead of long story points)
        print("✂️ 生成短版內容...")
        short_content = await generate_short_relationship_content(openai_client, story_content, scenario)
        
        # Generate conclusion
        print("💭 生成結論...")
        mock_story = {
            'hook': title_content['title'],
            'story_points': [{'title': 'Summary', 'description': short_content['content']}],
            'scenario': scenario
        }
        conclusion_content = await generate_relationship_conclusion_content(openai_client, mock_story)
        
        # Generate OPTIMIZED Instagram caption
        print("📱 生成優化版 Instagram caption...")
        instagram_caption = await generate_instagram_caption(openai_client, mock_story)
        
        # 🏷️ 生成標籤策略
        hashtag_strategy = ig_optimizer.generate_hashtag_strategy(scenario['theme'])
        
        # Save comprehensive report
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        with open('generated_ig_caption.txt', 'w', encoding='utf-8') as f:
            f.write(f"🎭 短版模式 - {scenario['theme']}\n")
            f.write(f"⏰ 生成時間：{timestamp}\n")
            f.write(f"📈 內容評分：{performance_analysis['score']}/100 ({performance_analysis['rating']})\n")
            f.write(f"🕐 最佳發布時間：{optimal_time}\n")
            f.write(f"🏷️ 標籤數量：{len(sum(hashtag_strategy.values(), []))} 個\n\n")
            
            f.write("=== 📊 優化建議 ===\n")
            for tip in performance_analysis['feedback']:
                f.write(f"• {tip}\n")
            
            f.write(f"\n=== 📱 Instagram Caption ===\n")
            f.write(instagram_caption['caption'])
            
            f.write(f"\n\n=== 🏷️ 標籤策略 ===\n")
            for category, tags in hashtag_strategy.items():
                f.write(f"📌 {category}: {' '.join(tags)}\n")
        
        # Create optimized templates
        print("🎨 創建優化模板...")
        templates = []
        
        # Title template
        title_template = generate_relationship_title_template(
            title_content, 
            title_content.get('keywords', []), 
            perspective
        )
        templates.append(('title.html', title_template))
        
        # Short content template (only one page)
        short_template = generate_short_relationship_content_template(
            short_content['content'],
            short_content.get('keywords', []),
            perspective
        )
        templates.append(('content_page1.html', short_template))
        
        # Conclusion template
        conclusion_template = generate_relationship_conclusion_template(
            conclusion_content,
            short_content.get('keywords', []),
            perspective
        )
        templates.append(('conclusion.html', conclusion_template))
        
        # End template
        end_template = generate_relationship_end_template(perspective)
        templates.append(('end.html', end_template))
        
        # Create images
        print("🖼️ 生成圖片...")
        template_dict = {}
        for filename, template_content in templates:
            template_name = filename.replace('.html', '')
            if template_name == 'content_page1':
                template_name = 'story1'
            template_dict[template_name] = template_content
        
        png_paths = await generate_images_from_templates(template_dict, f"short_{timestamp}")
        
        # Send to Telegram with optimization info
        if png_paths:
            print("📱 發送到 Telegram...")
            
            import telegram
            telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
            telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID")
            
            if not telegram_bot_token or not telegram_chat_id:
                # Load from .env file
                from dotenv import load_dotenv
                load_dotenv()
                telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
                telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID")
            
            bot = telegram.Bot(token=telegram_bot_token)
            
            # 增強版 caption 包含優化資訊
            enhanced_caption = f"""📱 短版感情故事分享 | {scenario['theme']} 主題
📈 內容評分：{performance_analysis['score']}/100
⏰ 建議發布：{optimal_time}
🏷️ {len(sum(hashtag_strategy.values(), []))} 個精準標籤

{instagram_caption['caption']}

💡 優化提示：{' | '.join(performance_analysis['feedback'][:2])}"""
            
            success = await send_telegram_photos(
                bot,
                telegram_chat_id,
                png_paths,
                enhanced_caption
            )
            if not success:
                print("❌ Telegram 發送失敗，但內容已生成完成")
        else:
            print("❌ 無圖片生成，跳過 Telegram 上傳")
        
        # 📅 顯示發布時間表
        schedule = ig_optimizer.get_posting_schedule(3)
        print(f"\n=== 📅 建議發布時間 ===")
        for day_plan in schedule:
            print(f"📅 {day_plan['date']} - {day_plan['time']} ({day_plan['reason']})")
        
        print("✅ 短版內容生成完成！")
        
    except Exception as e:
        print(f"❌ 短版內容生成錯誤: {e}")
        import traceback
        traceback.print_exc()

async def test_template_generation():
    """測試模板生成功能"""
    print("\n=== 🧪 測試模板生成 ===")
    
    # 添加 IG 優化器到測試
    ig_optimizer = InstagramOptimizer()
    
    # Use the predefined template
    template_data = RELATIONSHIP_STORY_TEMPLATES["superstition_plastic_surgery"]
    
    # 分析測試內容
    test_content = template_data['story_points'][0]['description'][:200]
    performance = ig_optimizer.analyze_content_performance(test_content)
    optimal_time = ig_optimizer.get_optimal_posting_time()
    
    print(f"📊 測試內容評分: {performance['score']}/100")
    print(f"⏰ 建議發布時間: {optimal_time}")
    
    templates = {
        'title': generate_relationship_title_template(
            {'title': template_data['title']}, 
            template_data['keywords']
        ),
        'story1': generate_relationship_story_template(
            template_data['story_points'][0], 
            template_data['keywords'],
            page_number=1
        ),
        'story2': generate_relationship_story_template(
            template_data['story_points'][1], 
            template_data['keywords'],
            page_number=2
        ),
        'story3': generate_relationship_story_template(
            template_data['story_points'][2], 
            template_data['keywords'],
            page_number=3
        ),
        'conclusion': generate_relationship_conclusion_template(
            {'conclusion': '大家覺得我應該點做？'}, 
            template_data['keywords']
        ),
        'end': generate_relationship_end_template()
    }
    
    # Generate images from templates
    print("\n=== 🖼️ 生成測試圖片 ===")
    png_paths = await generate_images_from_templates(templates, "test_optimized")
    
    if png_paths:
        print(f"✅ 成功生成 {len(png_paths)} 張圖片:")
        for path in png_paths:
            print(f"  📄 {path}")
    else:
        print("❌ 圖片生成失敗")
    
    return templates, png_paths

async def show_optimization_report():
    """顯示完整優化報告"""
    print("\n=== 📊 Instagram 優化報告 ===")
    
    ig_optimizer = InstagramOptimizer()
    
    # 測試內容
    test_content = "我同男朋友一齊咗12年，但佢為咗21歲既妹妹仔同我講分手。我真係好無奈，唔知點算好。"
    
    # 生成完整分析
    performance = ig_optimizer.analyze_content_performance(test_content)
    optimal_time = ig_optimizer.get_optimal_posting_time()
    hashtag_strategy = ig_optimizer.generate_hashtag_strategy(test_content)
    engagement = ig_optimizer.generate_engagement_content(test_content)
    schedule = ig_optimizer.get_posting_schedule(7)
    
    print(f"📈 內容評分: {performance['score']}/100 ({performance['rating']})")
    print(f"⏰ 最佳發布時間: {optimal_time}")
    print(f"🏷️ 標籤策略: {len(sum(hashtag_strategy.values(), []))} 個標籤")
    print(f"💡 優化建議:")
    for tip in performance['feedback']:
        print(f"  • {tip}")
    
    print(f"\n📅 一週發布時間表:")
    for day in schedule:
        print(f"  {day['date']} ({day['day']}) - {day['time']} - {day['reason']}")
    
    print(f"\n🎯 互動策略: {engagement['call_to_action']}")
    
    print(f"\n🏷️ 標籤分佈:")
    for category, tags in hashtag_strategy.items():
        print(f"  📌 {category} ({len(tags)}個): {' '.join(tags[:3])}...")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "short":
            # 短版內容生成（包含完整優化）
            asyncio.run(main_short_content())
        elif sys.argv[1] == "test":
            # 測試模式（包含優化分析）
            asyncio.run(test_template_generation())
        elif sys.argv[1] == "report":
            # 顯示優化報告
            asyncio.run(show_optimization_report())
        else:
            # 完整內容生成（包含完整優化）
            asyncio.run(generate_relationship_content()) 
    else:
        # 預設使用完整內容生成
        asyncio.run(generate_relationship_content()) 